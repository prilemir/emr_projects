from ultralytics import YOLO
import cv2
import threading
import queue
import time
import numpy as np


model = YOLO("runs/detect/train44/weights/best.pt")
model.fuse()


frame_queue = queue.Queue(maxsize=1)
result_queue = queue.Queue(maxsize=1)
stop_event = threading.Event()



def camera_worker():

    cap = cv2.VideoCapture(0)
    cap.set(cv2.CAP_PROP_FRAME_WIDTH, 640)
    cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)
    cap.set(cv2.CAP_PROP_FPS, 15)  # FPS 15 olarak sabitlendi

    while not stop_event.is_set():
        ret, frame = cap.read()
        if not ret:
            continue

        try:
            if frame_queue.full():
                frame_queue.get_nowait()
            frame_queue.put(frame.copy(), block=False)
        except queue.Full:
            pass

    cap.release()



def detection_worker():
    track_history = {}

    while not stop_event.is_set():
        try:
            frame = frame_queue.get(timeout=0.1)

            results = model.track(
                frame,
                persist=True,
                conf=0.4,
                iou=0.45,
                imgsz=640,
                device='cpu',
                verbose=False,
                tracker="botsort.yaml"
            )


            counts = {"helmet": 0, "no_helmet": 0}
            if results[0].boxes.id is not None:
                track_ids = results[0].boxes.id.int().cpu().numpy()
                classes = results[0].boxes.cls.int().cpu().numpy()

                for track_id, cls in zip(track_ids, classes):
                    if track_id not in track_history:
                        track_history[track_id] = time.time()
                        counts["helmet" if cls == 0 else "no_helmet"] += 1


            annotated = results[0].plot()
            try:
                if result_queue.full():
                    result_queue.get_nowait()
                result_queue.put((annotated, counts), block=False)
            except queue.Full:
                pass

        except queue.Empty:
            continue



camera_thread = threading.Thread(target=camera_worker)
detection_thread = threading.Thread(target=detection_worker)
camera_thread.daemon = True
detection_thread.daemon = True
camera_thread.start()
detection_thread.start()

# Ana thread (Görüntüleme ve kontrol)
total_counts = {"helmet": 0, "no_helmet": 0}

try:
    while True:
        # Sonuçları al ve göster
        try:
            annotated, counts = result_queue.get_nowait()

            # Toplam sayıları güncelle
            total_counts["helmet"] += counts["helmet"]
            total_counts["no_helmet"] += counts["no_helmet"]

            # Bilgileri ekrana yaz
            cv2.putText(annotated, f"Helmet: {total_counts['helmet']}", (10, 30),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 0), 2)
            cv2.putText(annotated, f"No Helmet: {total_counts['no_helmet']}", (10, 70),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 0, 255), 2)

            cv2.imshow('Helmet Detection', annotated)
        except queue.Empty:
            pass


        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

finally:
    stop_event.set()
    camera_thread.join()
    detection_thread.join()
    cv2.destroyAllWindows()