clc; clear;

s2 = System2(86);


[~, ~, y_step] = s2.step();
u_step = ones(size(y_step));
data_step = [u_step(:), y_step(:)];


[~, t_ramp, y_ramp] = s2.ramp();
u_ramp = t_ramp(:);
data_ramp = [u_ramp(:), y_ramp(:)];


s2 = s2.reset();
u_arb = linspace(0, 1, 100)';
y_arb = zeros(size(u_arb));

for i = 1:length(u_arb)
    [s2, y_arb(i)] = s2.output(u_arb(i));
end
data_arb = [u_arb(:), y_arb(:)];


all_data = [data_step; data_ramp; data_arb];
inputs = all_data(:,1);
outputs = all_data(:,2);


% Model: y(t) = f(u(t), u(t-1), y(t-1))
X = [inputs(2:end), inputs(1:end-1), outputs(1:end-1)];
Y = outputs(2:end);  


net = fitnet(10, 'trainlm');  % 10 nöronlu, Levenberg-Marquardt algoritması

% Eğitim oranları
net.divideParam.trainRatio = 0.8;
net.divideParam.valRatio = 0.1;
net.divideParam.testRatio = 0.1;

% Eğitim parametreleri
net.trainParam.epochs = 100;
net.trainParam.goal = 1e-6;

% Eğitimi başlat
[net, tr] = train(net, X', Y');

% Tahmin yap
Y_pred = net(X');

% Grafikle karşılaştır
figure;
plot(Y, 'b');
hold on;
plot(Y_pred, 'r--');
legend('Gerçek Çıkış', 'Tahmin (NN)');
title('Neural Network Çıkış Tahmini');
xlabel('Zaman Adımı');
ylabel('Çıkış');
grid on;
% Eğitim/Doğrulama/Test Hata Grafiği
figure;
plot(tr.epoch, tr.perf, 'b', 'LineWidth', 3); hold on;
plot(tr.epoch, tr.vperf, 'r--', 'LineWidth', 3);
plot(tr.epoch, tr.tperf, 'g:', 'LineWidth', 3);
legend('Eğitim Hatası', 'Doğrulama Hatası', 'Test Hatası');
xlabel('Epoch');
ylabel('Mean Squared Error (MSE)');
title('Eğitim Süreci - Loss Eğrisi');
grid on;
