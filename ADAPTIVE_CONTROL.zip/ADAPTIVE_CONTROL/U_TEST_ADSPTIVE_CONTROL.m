%% === Model ve Başlangıç Kontrolleri ===
if exist('net', 'var') == 0
    error('Eğitilmiş yapay sinir ağı modeli (net) bulunamadı.');
end

if net.inputs{1}.size ~= 3
    error('Bu kod yalnızca 3 girişli bir net modeli ile çalışır.');
end


Ts = 0.01;
sim_time = 30;
N = sim_time / Ts;
r = ones(1, N); 


K = 0.2;
eta1 = 0.1;
eta2 = 0.01;
eta3 = 0.05;
delta_p = 0.1;
delta_i = 0.4;
delta_d = 0.3;
alfa_p = 1;
alfa_i = 0.5;
alfa_d = 0.5;

%% === Başlangıç Değerleri ===
u = zeros(1, N+1);
y = zeros(1, N+1);

error_setpoint = zeros(1, N);
Integral_error = zeros(1, N);
D = zeros(1, N);
kp = zeros(1, N);
ki = zeros(1, N);
kd = zeros(1, N);
w1_updated = zeros(1, N+1);
w2_updated = zeros(1, N+1);
w3_updated = zeros(1, N+1);
w1_updated(1) = 0.005;
w2_updated(1) = 0.005;
w3_updated(1) = 0.005;


for x = 2:N
    % Geçerli hata
    error_setpoint(x) = r(x) - y(x);
    P = error_setpoint(x);

    % Integral ve türev terimleri
    Integral_error(x) = Integral_error(x-1) + error_setpoint(x);
    D(x) = error_setpoint(x) - error_setpoint(x-1);

    % Kazançlar
    kp(x) = K * w1_updated(x) / (w1_updated(x) + w2_updated(x) + w3_updated(x));
    ki(x) = K * w2_updated(x) / (w1_updated(x) + w2_updated(x) + w3_updated(x));
    kd(x) = K * w3_updated(x) / (w1_updated(x) + w2_updated(x) + w3_updated(x));

    % PID terimleri
    p_term = f(P, alfa_p, delta_p);
    i_term = f(Integral_error(x), alfa_i, delta_i);
    d_term = f(D(x), alfa_d, delta_d);

    % Kontrol sinyali hesapla
    u(x+1) = K * (w1_updated(x)*p_term + w2_updated(x)*i_term + w3_updated(x)*d_term) / ...
                  (w1_updated(x) + w2_updated(x) + w3_updated(x));
    
    if x <= 5
    u(x+1) = max(min(u(x+1), 0.5), -0.5);
    else
    u(x+1) = max(min(u(x+1), 2), -2);
    end


    % Net ile y_model hesapla: y(t) = f(u(t), u(t-1), y(t-1))
    y_model = net([u(x+1); u(x); y(x)]);  
    y(x+1) = y_model;

    % Ağırlık güncelle
    w1_updated(x+1) = w1_updated(x) + eta1 * error_setpoint(x) * u(x+1) * p_term;
    w2_updated(x+1) = w2_updated(x) + eta2 * error_setpoint(x) * u(x+1) * i_term;
    w3_updated(x+1) = w3_updated(x) + eta3 * error_setpoint(x) * u(x+1) * d_term;

    % Ağırlık sınırla
    w1_updated(x+1) = max(min(w1_updated(x+1), 10), -10);
    w2_updated(x+1) = max(min(w2_updated(x+1), 10), -10);
    w3_updated(x+1) = max(min(w3_updated(x+1), 10), -10);
end

%% === Zaman Vektörü ===
time_vec = Ts * (0:N-1);

figure;
plot(time_vec, r(1:N), 'r--', 'LineWidth', 1.5); hold on;
plot(time_vec, y(2:N+1), 'b', 'LineWidth', 1.5);
xlabel('Zaman (s)'); ylabel('Çıkış');
title('Referans Takibi (Adaptif PID + net)');
legend('Referans r(n)', 'Çıkış y(n)'); 
ylim([0 2]);        % Y ekseni sınırla
yticks(0:1:2);    % Y ekseni etiketleri
   % 1 saniye aralık

grid on;

figure;
subplot(2,1,1);
plot(time_vec, w1_updated(1:N), 'r', ...
     time_vec, w2_updated(1:N), 'b', ...
     time_vec, w3_updated(1:N), 'k', 'LineWidth', 1.2);
ylabel('Ağırlıklar'); xlabel('Zaman (s)');
title('Ağırlık Uyarlamaları'); legend('w1', 'w2', 'w3'); grid on;

subplot(2,1,2);
plot(time_vec, kp, 'r', time_vec, ki, 'b', time_vec, kd, 'k', 'LineWidth', 1.2);
ylabel('PID Kazançları'); xlabel('Zaman (s)');
title('Adaptif PID Kazançları'); legend('Kp', 'Ki', 'Kd'); grid on;

figure;
plot(time_vec, u(2:N+1), 'm', 'LineWidth', 1.5);
xlabel('Zaman (s)'); ylabel('Kontrol Sinyali u(n)');
title('Kontrol Sinyali Zamanla'); legend('u(n)'); grid on;



%% === Yardımcı Fonksiyon ===
function y = f(x, alfa, delta)
    if abs(x) > delta
        y = sign(x) * abs(x)^alfa;
    else
        y = (delta^(alfa-1)) * x;
    end
end
